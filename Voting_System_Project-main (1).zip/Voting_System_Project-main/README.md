# Voting_System_Project

This Voting System Project was developed by Group-8 of 6th Semester, NIT Durgapur. 
Developed for DBMS Group Project.
